import json
def readJsonFile(fileName):
    data=""