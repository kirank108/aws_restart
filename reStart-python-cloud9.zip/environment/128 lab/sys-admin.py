"""
Your module description
"""
import os
"""os.system("ls")"""
os.system("pwd")
#os.system("top")#
os.system("python")
os.system("cd..")
subprocess.run()