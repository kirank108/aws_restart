def getDoubleAlphabet(alphabet):
    return alphabet + alphabet

def getMessage():
    return input("Enter the message to be encrypted: ").upper()

def getCipherKey():
    return int(input("Enter the cipher key (1-25): "))

def encryptMessage(message, key, double_alphabet):
    encrypted_message = ""
    for char in message:
        index = double_alphabet.find(char)
        encrypted_message += double_alphabet[index + key]
    return encrypted_message

def decryptMessage(encrypted_message, key, double_alphabet):
    decrypted_message = ""
    for char in encrypted_message:
        index = double_alphabet.find(char)
        decrypted_message += double_alphabet[index - key]
    return decrypted_message

def runCaesarCipherProgram():
    myAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    print("Alphabet:", myAlphabet)
    myAlphabet2 = getDoubleAlphabet(myAlphabet)
    print("Alphabet2:", myAlphabet2)
    myMessage = getMessage()
    print("Message:", myMessage)
    myCipherKey = getCipherKey()
    print("Cipher Key:", myCipherKey)
    myEncryptedMessage = encryptMessage(myMessage, myCipherKey, myAlphabet2)
    print("Encrypted Message:", myEncryptedMessage)
    myDecryptedMessage = decryptMessage(myEncryptedMessage, myCipherKey, myAlphabet2)
    print("Decrypted Message:", myDecryptedMessage)

runCaesarCipherProgram()
