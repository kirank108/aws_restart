"""
Your module description
"""
import json

def readJsonFile(fileName):
    with open(fileName, 'r') as json_file:
        data = json.load(json_file)
        bInsulin = data['bInsulin']
        aInsulin = data['aInsulin']
        molecularWeightInsulinActual = data['molecularWeightInsulinActual']
        roughMolecularWeightInsulin = data['roughMolecularWeightInsulin']
        percentError = data['percentError']
        
        print("bInsulin: ", bInsulin)
        print("aInsulin: ", aInsulin)
        print("molecularWeightInsulinActual: ", molecularWeightInsulinActual)
        print("The rough molecular weight of insulin: ", roughMolecularWeightInsulin)
        print("Percent error: ", percentError)
        
fileName = "insulin_data.json"
readJsonFile(fileName)
